![Lightsaver Layout Image](https://i.imgur.com/KqdZQZZ.png)

# rasmusx's Lightsaver Layout

Custom keymap for Lightsaver.


## Features

* Default layer has ALT/SUPER switched and FN key in Caps Lock place.
* FN layer - Control RGB underglow and backlight. HJKL Vim style movement.
* Game layer - ALT/SUPER in normal positions. FN behaviour: 1 tap Caps Lock, 2 taps FN
