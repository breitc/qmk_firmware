![Lightsaver Layout Image](https://i.imgur.com/vRAy2XP.png)

# Default Lightsaver Layout

This is the default implement layout for Duck Lightsaver V3.


## Features

* Default QWERTY layer
* FN layer - Control RGB underglow and backlight. HJKL Vim style movement.
