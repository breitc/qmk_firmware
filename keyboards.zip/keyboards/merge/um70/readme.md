# UM-70

![UM-70](https://i.imgur.com/zrvMOZel.jpeg)

A 70 keys keyboard in 65% layout with encoder and OLED screen sold by Merge. [Product page](https://mergedesign.store/products/um-70)

* Keyboard Maintainer: [duoshock](https://github.com/duoshock)
* Hardware Availability: [Merge Store](https://mergedesign.store/products/um-70)

Make example for this keyboard (after setting up your build environment):

    make merge/um70:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).