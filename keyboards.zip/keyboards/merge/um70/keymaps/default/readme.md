# Default UM-70 Layout

![UM-70 Layout Image](https://i.imgur.com/5lucSbi.jpg)

This is the default layout that comes flashed on every UM-70.
