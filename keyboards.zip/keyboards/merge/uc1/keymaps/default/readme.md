# Default UC-1 Layout

![UC-1 Layout Image](https://i.imgur.com/TkaZ6jh.jpg)

This is the default layout that comes flashed on every UC-1.
