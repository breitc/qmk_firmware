# UC-1

![UC-1](https://i.imgur.com/rbuySDxl.jpg)

A 3 keys macro pad with 1 encoders made and sold by Merge. [Product page](https://mergedesign.store/products/uc-1)

* Keyboard Maintainer: [duoshock](https://github.com/duoshock)
* Hardware Availability: [Merge Store](https://mergedesign.store/products/uc-1)

Make example for this keyboard (after setting up your build environment):

    make merge/uc1:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).