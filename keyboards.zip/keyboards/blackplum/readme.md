# Blackplum
![Blackplum](https://i.imgur.com/EOUQk4J.png)

Blackplum a.k.a IMKG68 (which IMKG stands for Indonesian Mechanical Keyboard Group) is an 68% mechanical keyboard with RGB Underglow come with new layout you have never seen before. Recently the pcb and kits only available for purchase in Indonesia.

Keyboard Maintainer: [eriqadams](https://github.com/eriqadams)  
Hardware Supported: Blackplum PCB, ATMEGA32u4-au MCU  
Hardware Availability: [If you're in Indonesia you can purchase here](https://tokopedia.com/pixlup) 

Make example for this keyboard (after setting up your build environment):

    make blackplum:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
