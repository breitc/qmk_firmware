# The default keymap for Abacus

This is made based on my first few days of playing with it and honing in on what feels right.
I've repurposed the DIP switch function for the encoder switches and added some functionality for multiple layers also effecting the encoders output.
