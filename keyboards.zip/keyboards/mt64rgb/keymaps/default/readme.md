# Default mt4rgb Layout

This is the default layout that comes flashed on every mt64rgb. All key pins are shown in the file.
