# space_space

![space_space](https://i.imgur.com/SxjhzIMh.jpg)

Give your space some space  

* Keyboard Maintainer: https://github.com/qpockets
* Hardware Availability: https://p3dstore.com/products/space-space-acrylic-case?_pos=21&_sid=c75de6a78&_ss=r&variant=39907740844216

Make example for this keyboard (after setting up your build environment):

    make space_space/rev2:default

Flashing example for this keyboard:

    make space_space/rev2:default:flash

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
