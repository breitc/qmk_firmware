# SUV

This is 100% keyboard with the standard layout of a 104-key setup.

- Keyboard Maintainer: [AAClawson](https://github.com/AlisGraveNil)
- Hardware Supported: SUV, Elite-C
- Hardware Availability: In stock within the next month

Make example for this keyboard (after setting up your build environment):

    make clawsome/suv:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
