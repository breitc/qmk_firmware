# GameBuddy

This is a 5x7 macropad designed for left OR right hand usage in videogames, with special focus on FPS layouts!

* Keyboard Maintainer: [AAClawson](https://github.com/AlisGraveNil)
* Hardware Supported: GameBuddy, Pro Micro, Elite-C, nice!nano
* Hardware Availability: www.clawboards.xyz

Make example for this keyboard (after setting up your build environment):

    make clawsome/gamebuddy/v1_m:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
