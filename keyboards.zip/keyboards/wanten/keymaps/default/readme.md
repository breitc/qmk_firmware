# The default keymap for wanten
