# The Railroad

![The Railroad](https://i.imgur.com/B8OjXmyl.jpg)

A long keyboard with ortholinear alphas and semi-standard modifier keys. For more information, join the [NoPunIn10Key Discord](https://discord.gg/sku2Y6w).

* Keyboard Maintainer: [Alex Ronke](diplomacyvariants.wordpress.com), also known as NoPunIn10Did. 
* Hardware Supported: The Railroad: 2020-07 Prototype
* Hardware Availability: Currently by request only

Make example for this keyboard (after setting up your build environment):

    make nopunin10did/railroad/rev0:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
