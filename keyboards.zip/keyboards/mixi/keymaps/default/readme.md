![Mixi Layout Image](https://i.imgur.com/WCtQ6GG.jpg)

# Default Mixi Layout

This is the default layout that comes flashed on every Mixi macropad. Layer 1
and Layer 2 are accessible by rotating the encoder. Layer 3 is not accessible
by the encoder, instead is accessible by holding the [0,2] key on Layer 1. While
Layer 3 is active, rotating the encoder will results in increasing/decreasing
media volume. This layout is expected the encoder is on the left side or [0,0]
key.
