# Combo library!

This is a list of all the currently available dictionaries that are available for inclusion.
Please submit a PR with yours! If you have a bunch prepend your username to the front. i.e. 
`germ-vim-helpers`

Thanks!
