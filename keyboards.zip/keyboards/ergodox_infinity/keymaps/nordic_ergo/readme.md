# Nordic Ergodox Infinity layout

QWERTY Nordic layout for ergodox infinity.

Features:

- Basic ISO Nordic qwerty layout.
- Backlight control.
- Still work in progress.