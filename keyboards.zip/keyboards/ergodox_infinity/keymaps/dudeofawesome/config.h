#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#undef TAPPING_TOGGLE

#include "../../config.h"
#include "dudeofawesome.h"

#endif
