#include QMK_KEYBOARD_H

enum custom_layers {
  _QWERTY,
  _WORKMAN,
  _DVORAK,
  _COLEMAK,
  _LOWER,
  _RAISE,
  _ADJUST,
  _GAME,
  _MOUSE,
  _NUM,
};
