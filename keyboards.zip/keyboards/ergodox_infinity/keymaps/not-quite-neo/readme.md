# not-quite-neo

This is my personal take on porting the [neo2 layout](https://www.neo-layout.org/) to support multiple keyboards. 

Refer to the [readme.md](../../../../users/not-quite-neo/readme.md) of the generic parts of the implementation.