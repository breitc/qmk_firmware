# Truly Ergonomic like layout

A basic ErgoDox layout that imitates the Truly Ergonomic keyboard layout.
