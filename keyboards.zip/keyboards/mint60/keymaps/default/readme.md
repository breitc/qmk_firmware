# The default keymap for Mint60
