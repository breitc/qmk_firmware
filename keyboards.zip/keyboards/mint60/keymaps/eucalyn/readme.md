# The Eucalyn keymap for Mint60

It use "Eucalyn" Kemboard Layout.
