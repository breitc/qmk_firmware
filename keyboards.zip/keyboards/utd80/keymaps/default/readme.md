# The default keymap for UTD80
