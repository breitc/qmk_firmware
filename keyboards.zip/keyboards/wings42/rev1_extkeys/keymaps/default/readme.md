# The default keymap for wings42
